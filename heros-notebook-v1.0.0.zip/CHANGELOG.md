# Changelog — Heros NoteBook

## v1.0.0 — 2026-10-14

First release. 135 free & unlimited tools.

- View any `.ipynb`: file, drag-drop, URL, `?nb=`, paste, demo, recents
- Run real Python free (Pyodide sandbox): run cell/all/above, restart,
  `!pip install`, `input()`, matplotlib PNG capture, rich display
- Edit: add/split/cut/copy/paste/duplicate/delete/move, type switch,
  live markdown preview, Tab indent, undo/redo
- Search all (code + markdown + outputs), outline, navigator, error jump
- Export `.ipynb/.py/.md/.html/.txt`, print/PDF, backup/restore, cell links
- Heros PDF design: floating cards, pill tabs, dark/light/system,
  6 accents, night/sepia/dim, 4 widths, focus, fullscreen, mobile drawer
- Study marks (H/U/S/C), notes, bookmarks; stopwatch, counters, todo,
  habits, streaks, reading timer; notebook lab (lint/summary/keywords/…)
- MV3, popup, context menu, auto-open toggles, 100% local, offline view
