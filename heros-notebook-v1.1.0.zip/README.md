# Heros NoteBook — Jupyter viewer + runner for your browser

The fastest, most private, most beautiful way to open **`.ipynb`** files in
Chrome, Edge and Brave. **Read – Run Python free – Edit – Search – Export –
100% local viewing – Free – Unlimited.**

Design copied from **Heros PDF** studio (same ultra-rounded floating cards,
pill toolbars, Dark + Light, silent instant boot, mobile-ready).
`Heros_Markdown` and `Heros_PDF` were only read — never touched.

## Install (30 seconds)

1. Open `chrome://extensions` (Edge: `edge://extensions`, Brave: `brave://extensions`)
2. Enable **Developer mode**
3. **Load unpacked** → select the `Heros_Jupter` folder
4. Pin **Heros NoteBook**, click it → viewer opens
5. For `file://` auto-open: extension **Details** → **Allow access to file URLs**

Or open `viewer.html` directly — no install needed for viewing.

## Feature universe — all 160, free & unlimited

Press **F** in the app for the runnable list. Every card runs. New in v1.1.0:
**Builder studio**, **variable inspector**, **package manager**,
**plot gallery**, **run history**, **Studio-white light mode**,
**reduce-motion switch**, **profile colors**.

### Open & View (18)

Open .ipynb file · drag & drop anywhere · open from URL · `?nb=` deep open ·
paste notebook JSON · demo notebook · recent notebooks (25) · resume at last
cell · notebook header · kernelspec badge · trust bar · HTML sanitizing ·
lazy images · collapse all outputs · execution badges · auto-collapsed
streams · cell permalinks · go to cell number

### Run Python (14)

Run cell (Shift+Enter) · run cell stay (Ctrl+Enter) · run + insert below ·
run all · run cells above · restart kernel · load kernel now ·
`!pip install` support · `input()` prompts · matplotlib inline ·
rich display (HTML/SVG/PNG/Markdown/JSON) · per-cell timers · kernel info ·
safe magics

### Edit (19)

Add code / markdown / above · split at cursor · cut / copy / paste /
duplicate / delete · move up / down · to code / markdown / raw ·
edit-preview toggle · collapse source / outputs · undo / redo (50 steps)

### Search & Navigate (11)

Full-notebook search (code + markdown + outputs) · case · whole-word ·
prev / next · export results · cell navigator · outline (headings +
def/class) · go to cell · jump to first error · back to top

### Export & Share (14)

Save .ipynb · export .py / .md / .html / .txt · print / PDF ·
copy source / outputs · download plot images · backup / restore ·
share cell link · duplicate notebook · validate notebook

### Themes & Comfort (13)

Dark / light / system · 6 accents + custom · night / sepia / dim pages ·
4 widths · font scaling · focus mode · fullscreen

### Study & Marks (10)

Highlight / underline / strike selection (H/U/S) · copy selection ·
note from selection · auto-saved marks · cell bookmarks · notebook notes ·
callouts + tables · safe external links

### Productivity (14)

Stopwatch + laps · unlimited counters + steps · todo + priorities +
filters + export + clear-done · habit tracker + streaks · day streak ·
auto reading timer

### Platform & Privacy (12)

Manifest V3 · popup control center · right-click open · auto-open
local / web · file-permission helper · 100% local · zero tracking ·
offline view/edit/export · zero dependencies · silent boot · MIT free forever

### Lab (10)

Lint · summary · keywords · readability · copy outline / stats ·
validate · execution stats · kernel info · word counts

### Build — snippet studio + wizards (12)

Snippet gallery · table builder · chart wizard · CSV loader ·
quick line chart · pip installer cell · JSON loader · callout builder ·
math block · details fold · banner box · task-list block

### Data — live kernel power (8)

Variable inspector · variable detail · package manager · one-tap pip ·
plot gallery · run history · auto variable refresh · shape badges

### Design — perfect light + dark (5)

Studio white · true dark · reduce motion · profile color · studio profile

## Keyboard

`Ctrl+O` open · `Ctrl+S` save · `Ctrl+F` search · `Ctrl+K` commands ·
`Ctrl+B` sidebar · `Shift+Enter` run+next · `Ctrl+Enter` run+stay ·
`J/K` navigate · `A/B/M` add cells · `V` paste · `E` edit · `T` theme ·
`F` features · `?` help · `Esc` close

## Privacy

No server, no analytics, no account. Notebooks stay in memory + `blob:`
URLs. Recents, autosaves, marks, notes and tools live only in your browser
profile. The Python kernel runs isolated in a sandbox iframe and contacts
the CDN once to download itself. Untrusted notebooks render sanitized HTML.

## Files

```text
Heros_Jupter/
├── manifest.json      MV3, v1.0.0 (extension_pages self-only; sandbox for kernel)
├── viewer.html        app shell + Heros-PDF-grade design system
├── app.js             viewer/runner/edit/search/export engine (~3000 lines)
├── sandbox.html/js    isolated Pyodide kernel bridge
├── background.js      auto-open file:// + https:// .ipynb, context menu
├── popup.html/js      toolbar control center
└── icons/             logo + 16/32/48/128
```

MIT licensed. Free and unlimited forever.
